import { useState } from "react";
import Sidebar, { type Page } from "./components/Sidebar";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import IncomingRequests from "./components/IncomingRequests";
import ActiveJobs from "./components/ActiveJobs";
import Messages from "./components/Messages";
import Notifications from "./components/Notifications";
import PublicProfile from "./components/PublicProfile";
import Analytics from "./components/Analytics";
import Earnings from "./components/Earnings";
import Settings from "./components/Settings";

const HelpPage = () => (
  <div style={{ padding: 32, color: "#909090", fontSize: 14 }}>Help & Support coming soon…</div>
);

export default function App() {
  const [activePage, setActivePage] = useState<Page>("dashboard");

  const fullscreenPages: Page[] = ["requests", "jobs", "messages", "settings"];
  const isFullscreen = fullscreenPages.includes(activePage);

  const renderPage = () => {
    switch (activePage) {
      case "dashboard": return <Dashboard onNavigate={setActivePage} />;
      case "requests": return <IncomingRequests />;
      case "jobs": return <ActiveJobs />;
      case "messages": return <Messages />;
      case "notifications": return <Notifications />;
      case "profile": return <PublicProfile />;
      case "analytics": return <Analytics />;
      case "earnings": return <Earnings />;
      case "settings": return <Settings />;
      case "help": return <HelpPage />;
    }
  };

  return (
    <div style={{
      background: "#0A0A0A",
      minHeight: "100vh",
      fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
    }}>
      <Sidebar activePage={activePage} onNavigate={setActivePage} />
      <Header activePage={activePage} onNavigate={setActivePage} />

      {/* Main content */}
      <div style={{
        marginLeft: 240,
        paddingTop: 60,
        minHeight: "100vh",
        overflowY: isFullscreen ? "hidden" : "auto",
      }}>
        {renderPage()}
      </div>
    </div>
  );
}
